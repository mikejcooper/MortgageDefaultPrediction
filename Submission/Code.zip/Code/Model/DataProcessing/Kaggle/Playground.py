

class Playground:
    """ A class that parses input data from file. """

    def __init__(self):
        """ Example of docstring on the __init__ method.  """


        # self.ml_model(data_frame)


if __name__ == "__main__":
    Playground()
    print("hello world")

